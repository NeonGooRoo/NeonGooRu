Script_Triggered_Pause = false
mX_Buffer = ""
mY_Buffer = ""

mp.add_periodic_timer(0.1, function()
	local mX, mY = mp.get_mouse_pos()
	if mX ~= mX_Buffer or mY ~= mY_Buffer then
		mX_Buffer = mX
		mY_Buffer = mY

		local dim = mp.get_property_native("osd-dimensions")

		-- print(mX .. "x" .. mY .. " - " .. dim.w .. "x" .. dim.h .. " - " .. mY/dim.h)

		-- Trigger for the lower 20% of the displayed movie
		if mY/dim.h > 0.80 then
			if mp.get_property("pause") == "no" then
				if Script_Triggered_Pause == false then
					-- print("Pause")
					mp.set_property("pause", "yes")
					Script_Triggered_Pause = true
				end
			end
		elseif Script_Triggered_Pause == true then
			-- print("Un-Pause")
			mp.set_property("pause", "no")
			Script_Triggered_Pause = false
		end
	end
	--
end)